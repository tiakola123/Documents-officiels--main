export default function App() {
  return (
    <div style={{ fontFamily: 'Arial', padding: '20px' }}>
      <h1>Documents Officiels 🇲🇫🇧🇪🇨🇦</h1>
      <p>Obtenez votre carte VTC, titre de séjour, passeport et autres documents officiels.</p>
      <ul>
        <li>Carte VTC</li>
        <li>Titre de séjour</li>
        <li>Passeport</li>
      </ul>
      <h2>Contact</h2>
      <p>Telegram : <a href="https://t.me/vtcfree">@vtcfree</a></p>
      <p>Email : <a href="mailto:titrekondesejours@gmail.com">titrekondesejours@gmail.com</a></p>
    </div>
  );
}
